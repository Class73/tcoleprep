function shuffle(array) {

    const arr = [...array];

    for (let i = arr.length - 1; i > 0; i--) {

        const j = Math.floor(Math.random() * (i + 1));

        [arr[i], arr[j]] = [arr[j], arr[i]];
    }

    return arr;
}

function startExam(count) {

    const questions =
        shuffle(window.masterBank)
        .slice(0, count);

    const container =
        document.getElementById("quizContainer");

    container.innerHTML = "";

    questions.forEach((q, index) => {

        const div =
            document.createElement("div");

        div.className = "question";

        div.innerHTML = `
            <h3>${index + 1}. ${q.prompt}</h3>

            ${q.options.map(opt => `
                <label>
                    <input
                        type="radio"
                        name="${q.id}"
                        value="${opt.id}">
                    ${opt.id}. ${opt.text}
                </label>
            `).join("")}
        `;

        container.appendChild(div);
    });
}